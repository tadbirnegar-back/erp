<?php

return [
    'name' => 'HRMS',
];
