<?php

namespace Modules\HRMS\app\Http\Enums;

enum FreeZonePositionsEnum: int
{
    const MASOULE_DABIR = 'مسئول دبیر';

    const BOSS_FREE_ZONE = 'رئیس‌ منطقه آزاد';

}
