<?php

namespace Modules\HRMS\app\Http\Controllers;

use App\Http\Controllers\Controller;

class ScriptStatusController extends Controller
{

}
