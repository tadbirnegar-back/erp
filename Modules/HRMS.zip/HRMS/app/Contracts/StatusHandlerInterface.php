<?php

namespace Modules\HRMS\app\Contracts;

interface StatusHandlerInterface
{
    public function execute(): void;

}
