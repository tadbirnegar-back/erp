<?php

namespace Modules\LMS\app\Http\Controllers;

use App\Http\Controllers\Controller;
use http\Env\Response;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Modules\AAA\app\Models\User;
use Modules\AddressMS\app\Models\City;
use Modules\AddressMS\app\Models\District;
use Modules\AddressMS\app\Models\State;
use Modules\LMS\app\Http\Services\PurchaseCourse;
use Modules\LMS\app\Http\Services\VerificationPayment;
use Modules\LMS\app\Http\Traits\CourseCourseTrait;
use Modules\LMS\app\Http\Traits\CourseEmployeeFeatureTrait;
use Modules\LMS\app\Http\Traits\CourseTargetTrait;
use Modules\LMS\app\Http\Traits\CourseTrait;
use Modules\LMS\app\Models\Course;
use Modules\LMS\app\Models\CourseCourse;
use Modules\LMS\app\Resources\AllCoursesListResource;
use Modules\LMS\app\Resources\CourseListResource;
use Modules\LMS\app\Resources\CourseShowForUpdateResource;
use Modules\LMS\app\Resources\CourseViewLearningResource;
use Modules\LMS\app\Resources\LessonDetailsResource;
use Modules\LMS\app\Resources\LessonListResource;
use Modules\LMS\app\Resources\LiveOunitSearchForCourseResource;
use Modules\LMS\app\Resources\SideBarCourseShowResource;
use Modules\LMS\app\Resources\ViewCourseSideBarResource;
use Modules\OUnitMS\app\Models\CityOfc;
use Modules\OUnitMS\app\Models\DistrictOfc;
use Modules\OUnitMS\app\Models\OrganizationUnit;
use Modules\OUnitMS\app\Models\StateOfc;
use Modules\OUnitMS\app\Models\VillageOfc;
use Modules\PayStream\app\Models\Online;

class CourseController extends Controller
{
    use CourseTrait, CourseCourseTrait, CourseTargetTrait, CourseEmployeeFeatureTrait;

    public function store(Request $request)
    {
        try {
            DB::beginTransaction();
            $data = $request->all();
            $user = Auth::user();
            //Store Course base datas
            $course = $this->storeCourseDatas($data, $user);
            //Store course Status
            $this->storePishnevisStatus($course->id);
            //store preRequisites
            if (isset($data['preRequisiteCourseIDs']) && !is_null($data['preRequisiteCourseIDs'])) {
                $this->storePreRequisite($course->id, $data['preRequisiteCourseIDs']);
            }
            //Store Target Points
            if (isset($data['courseTargets'])) {
                $this->storeCourseTarget($course->id, $data['courseTargets']);
            }
            DB::commit();
            return response()->json(['message' => "دوره با موفقیت ساخته شد"]);
        } catch (\Exception $exception) {
            DB::rollBack();
            return response()->json(['message' => $exception->getMessage()]);
        }
    }

    public function update(Request $request, $id)
    {
        $data = $request->all();
        $course = Course::find($id);
        $course = $this->updateCourseDatas($course, $data);
        //store preRequisites
        if (isset($data['preRequisiteCourseIDs'])) {
            $this->storePreRequisite($course->id, $data['preRequisiteCourseIDs']);
        }
        //Store Target Points
        if (isset($data['courseTargets'])) {
            $this->storeCourseTarget($course->id, $data['courseTargets']);
        }

        //Delete pre requisites
        if (isset($data['preReqDeletedIDs'])) {
            $reqIDs = json_decode($data['preReqDeletedIDs']);
            $this->deletePreRequisite($reqIDs);
        }


        if (isset($data['courseTargetsIDs'])) {
            $ctIDs = json_decode($data['courseTargetsIDs']);
            $this->deleteCourseTarget($ctIDs);
        }
    }

    public function updateDataShow($id)
    {
        $course = Course::find($id);
        if (empty($course)) {
            return response()->json(['message' => "همچین دوره ای وجود ندارد"], 403);
        }
        $data = $this->showCourseForUpdate($id);
        return new CourseShowForUpdateResource($data);
    }

    public function show($id)
    {
        try {
            $course = Course::whereHas('latestStatus', function ($query) {
                $query->whereIn('statuses.id', [
                    $this->coursePresentingStatus()->id,
                    $this->courseEndedStatus()->id,
                    $this->courseCanceledStatus()->id
                ]);
            })->with('latestStatus')->find($id);
            $user = Auth::user();
            if (is_null($course) || empty($course->latestStatus)) {
                return response()->json(['message' => 'دوره مورد نظر یافت نشد'], 403);
            }

            $componentsToRenderWithData = $this->courseShow($course, $user);
            return response()->json($componentsToRenderWithData);
        } catch (\Exception $e) {
            return response()->json(['message' => 'دوره مورد نظر یافت نشد'], 403);
        }
    }

    public function courseList(Request $request)
    {
        $data = $request->all();
        $perPage = $data['perPage'] ?? 10;
        $pageNum = $data['pageNum'] ?? 1;

        $result = $this->courseIndex($perPage, $pageNum, $data);
        $response = new CourseListResource($result);

        return $response;
    }


    public function registerCourse($id)
    {
        try {
            DB::beginTransaction();

            $course = Course::with('prerequisiteCourses')->find($id);

            $user = Auth::user();
            // Check if the user has completed prerequisite courses.
            // This is currently implemented in the simplest possible way and might be updated in the future.
            if (empty($course->prerequisiteCourses[0])) {
                $isPreDone = true;
            } else {
                $isPreDone = $this->isJoinedPreRerequisites($user, $course);
            }
            if ($isPreDone) {
                $purchase = new PurchaseCourse($course, $user);
                $response = $purchase->handle();
            } else {

                return response()->json([
                    'success' => false,
                    'message' => 'پیش نیاز های دوره مطالعه نشده است',
                ], 400);
            }


            DB::commit();

            return response()->json($response);
        } catch (\Exception $e) {
            DB::rollBack();

            return response()->json([
                'success' => false,
            ], 500);
        }
    }

    public function checkPayment(Request $request)
    {
        $data = $request->all();
        $validator = Validator::make($data, [
            'authority' => [
                'required',
                'exists:onlines,authority'
            ]
        ]);
        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }
        $online = Online::where('authority', $data['authority'])->first();
        try {
            DB::beginTransaction();
            $verify = new VerificationPayment($online);
            $result = $verify->verifyPayment();
            DB::commit();
            return response()->json($result);
        } catch (\Exception $exception) {
            DB::rollBack();
            DB::beginTransaction();
            $verify = new VerificationPayment($online);
            $result = $verify->DeclinePayment();
            DB::commit();
            return response()->json($result);
        }

    }

    public function lessonList(Request $request)
    {


        $data = $request->all();
        $perPage = $data['perPage'] ?? 10;
        $pageNum = $data['pageNum'] ?? 1;

        $result = $this->lessonIndex($perPage, $pageNum, $data);
        $response = new LessonListResource($result);

        return $response;


    }

    public function learningShow($id)
    {
        $course = Course::leftJoinRelationship('chapters.lessons')->whereHas('latestStatus', function ($query) {
            $query->whereIn('statuses.id', [
                $this->coursePresentingStatus()->id,
                $this->courseEndedStatus()->id,
            ]);
        })->find($id);
        if (empty($course)) {
            return response()->json(["message" => "دوره با این مشخصات وجود ندارد"], 403);
        }
        $user = Auth::user();
        $isEnrolled = $this->isEnrolledToDefinedCourse($course->id, $user);

        //Check user is Joined or not
        if (empty($isEnrolled->isEnrolled[0])) {
            $joined = false;
        } else {
            $joined = true;
        }
        if (!$joined) {
            return response()->json(["message" => "شما دسترسی به این دوره را ندارید"], 400);
        }

        $data = $this->dataShowViewCourseSideBar($course, $user);

        $sidebar = new SideBarCourseShowResource($data);
        return response()->json($sidebar);

    }


    public function courseListAll()
    {
        $query = Course::query();

        $course = $query->select('id', 'title')->get();

        $response = AllCoursesListResource::collection($course);

        return response()->json($response);
    }


    public function liveSearchOunit(Request $request)
    {
        $data = $request->all();
        $searchTerm = $data['name'] ?? '';

        $results = OrganizationUnit::query()
            ->where('name', 'like', '%' . $searchTerm . '%')
            ->whereIn('unitable_type', [StateOfc::class, CityOfc::class, DistrictOfc::class, VillageOfc::class])
            ->take(7)
            ->with([
                'ancestors',
                'unitable'
            ])
            ->get();

        $response = LiveOunitSearchForCourseResource::collection($results);

        return response()->json($response);
    }

}
