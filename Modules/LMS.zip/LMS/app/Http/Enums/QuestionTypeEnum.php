<?php

namespace Modules\LMS\app\Http\Enums;
enum QuestionTypeEnum: string
{
    case MULTIPLE_CHOICE_QUESTIONS = "تستی";
    case DESCRIPTIVE_QUESTIONS = "تشریحی";
}
