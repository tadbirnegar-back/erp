<?php

namespace Modules\LMS\app\Http\Enums;
enum QuestionsEnum: string
{
    case ACTIVE = 'فعال';
    case EXPIRED = 'منسوخ شده ';
}
