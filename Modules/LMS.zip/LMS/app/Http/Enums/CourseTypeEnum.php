<?php

namespace Modules\LMS\app\Http\Enums;

enum CourseTypeEnum: int
{
    case AMUZESHI = 1;
    case MOKATEBEYI = 2;

}
