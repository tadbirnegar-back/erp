<?php

namespace Modules\LMS\app\Http\Enums;

enum LessonStatusEnum: string
{
    case ACTIVE = "فعال";
    case IN_ACTIVE = "غیر فعال";

}
