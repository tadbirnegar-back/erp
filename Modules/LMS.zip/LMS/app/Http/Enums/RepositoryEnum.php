<?php

namespace Modules\LMS\app\Http\Enums;
enum RepositoryEnum: string
{
    case PACTICE = 'تمرینی ';
    case FINAL = 'نهایی ';

}
