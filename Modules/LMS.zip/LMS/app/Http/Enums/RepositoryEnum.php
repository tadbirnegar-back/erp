<?php

namespace Modules\LMS\app\Http\Enums;
enum RepositoryEnum: string
{
    case PRACTICE = 'تمرینی';
    case FINAL = 'نهایی';

}
