<?php

namespace Modules\LMS\app\Http\Enums;
enum ExamsStatusEnum: string
{
    case CONFIRMED = "قبول";
    case FAILED = "مردود";

}
