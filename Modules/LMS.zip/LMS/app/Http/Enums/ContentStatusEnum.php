<?php

namespace Modules\LMS\app\Http\Enums;

enum ContentStatusEnum: string
{
    case ACTIVE = "فعال";
    case IN_ACTIVE = "غیر فعال";

}
