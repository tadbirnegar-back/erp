<?php

namespace Modules\LMS\app\Http\Enums;
enum SettingEnum: string
{
    case DIFFICULTY = 'Difficulty';
    case QUESTION_TYPE = 'question_type';

}
