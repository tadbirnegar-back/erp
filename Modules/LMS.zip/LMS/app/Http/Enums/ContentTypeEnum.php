<?php

namespace Modules\LMS\app\Http\Enums;
enum ContentTypeEnum: string
{
    case AUDIO = 'صوتی';
    case VIDEO = 'تصویری';
}
