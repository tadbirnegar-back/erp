<?php

return [
    'name' => 'LMS',
];
