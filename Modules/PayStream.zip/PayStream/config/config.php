<?php

return [
    'name' => 'PayStream',
];
