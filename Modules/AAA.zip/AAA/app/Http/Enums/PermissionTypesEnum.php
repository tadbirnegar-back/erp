<?php

namespace Modules\AAA\app\Http\Enums;

enum PermissionTypesEnum: int
{
    case SIDEBAR = 1;
    case OPERATIONAL = 2;
    case WIDGET = 3;
}
