<?php

namespace Modules\PFM\app\Http\Enums;

enum ApplicationsCoefficientEnum: string
{
    case residential = 'p_residential';
    case commercial = 'p_commercial';
    case administrative = 'p_administrative';



}
