@extends('vcm::layouts.master')

@section('content')
    <h1>Hello World</h1>

    <p>Module: {!! config('vcm.name') !!}</p>
@endsection
