<?php

namespace Modules\EMS\app\Http\Enums;

enum EnactmentTitleStatusEnum: string
{
    case ACTIVE = 'فعال';
    case DELETED = 'حذف شده';

}
