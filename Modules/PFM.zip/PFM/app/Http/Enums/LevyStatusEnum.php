<?php

namespace Modules\PFM\app\Http\Enums;

enum LevyStatusEnum: string
{
    case ACTIVE = 'فعال';

    case NOT_ACTIVE = 'غیر فعال';

}
