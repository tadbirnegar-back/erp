<?php

namespace Modules\PFM\app\Http\Enums;

enum PfmCircularStatusesEnum: string
{
    case PUBLISHED = 'ابلاغ شده';

    case DRAFT = 'پیش نویس';

}
