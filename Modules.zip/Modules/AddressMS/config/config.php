<?php

return [
    'name' => 'AddressMS',
];
