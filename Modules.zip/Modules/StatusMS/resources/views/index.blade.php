@extends('statusms::layouts.master')

@section('content')
    <h1>Hello World</h1>

    <p>Module: {!! config('statusms.name') !!}</p>
@endsection
