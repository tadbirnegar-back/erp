<?php

return [
    'name' => 'StatusMS',
];
