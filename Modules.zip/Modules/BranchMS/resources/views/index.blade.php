@extends('branchms::layouts.master')

@section('content')
    <h1>Hello World</h1>

    <p>Module: {!! config('branchms.name') !!}</p>
@endsection
