<?php

return [
    'name' => 'BranchMS',
];
