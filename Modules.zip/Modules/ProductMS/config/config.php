<?php

return [
    'name' => 'ProductMS',
];
