<?php

namespace Modules\CustomerMS\app\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Modules\AddressMS\app\services\AddressService;
use Modules\CustomerMS\app\Http\Services\CustomerService;
use Modules\PersonMS\App\Http\Services\PersonService;

class CustomerMSController extends Controller
{
    public array $data = [];
    protected $personSevice;
    protected $customerService;
    protected $addressService;
    public function __construct(CustomerService $customerService, PersonService $personService,AddressService $addressService)
    {
        $this->personSevice = $personService;
        $this->customerService = $customerService;
        $this->addressService = $addressService;
    }

    /**
     * Display a listing of the resource.
     */
    public function index(): JsonResponse
    {
        //

        return response()->json($this->data);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request): JsonResponse
    {
        $data = $request->all();

        if ($request->personableType == 'natural') {

            if ($request->isNewNatural) {

                if ($request->isNewAddress) {
                    $address = $this->addressService->store($data);
                    if ($address instanceof \Exception) {
                        return response()->json(['message' => 'خطا در ایجاد مشتری'], 500);
                    }
                    $data['homeAddressID']=$address->id;
                }

                $naturalResult = $this->personSevice->naturalStore($data);
                if ($naturalResult instanceof \Exception) {
                    return response()->json(['message' => 'خطا در ایجاد مشتری'], 500);
                }
                $data['personID'] = $naturalResult->person->id;
            }
            $data['userID']=\Auth::user()->id;

            $insertedCustomer=$this->customerService->store($data);

            if ($insertedCustomer instanceof \Exception) {
                return response()->json(['message' => 'خطا در ایجاد مشتری'], 500);
            }

        }
// elseif ($request->personableType == 'legal') {
//            if ($request->isNewLegal) {
//
//            }
//        }


        return response()->json($insertedCustomer);
    }

    /**
     * Show the specified resource.
     */
    public function show($id): JsonResponse
    {
        //

        return response()->json($this->data);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id): JsonResponse
    {
        //

        return response()->json($this->data);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id): JsonResponse
    {
        //

        return response()->json($this->data);
    }
}
