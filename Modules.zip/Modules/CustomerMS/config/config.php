<?php

return [
    'name' => 'CustomerMS',
];
